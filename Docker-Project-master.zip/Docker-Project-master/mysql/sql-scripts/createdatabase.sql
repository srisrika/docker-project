CREATE TABLE MyUsers (
firstname varchar(25),
lastname  varchar(25)
);
GRANT ALL PRIVILEGES ON *.* TO 'root'@'%';
